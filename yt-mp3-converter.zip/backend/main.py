from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from yt_dlp import YoutubeDL
import os

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/convert")
def convert(url: str = Query(...)):
    ydl_opts = {
        'format': 'bestaudio/best',
        'outtmpl': 'downloads/%(title)s.%(ext)s',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
    }

    try:
        with YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            title = info.get('title', 'audio')
            filename = ydl.prepare_filename(info).replace('.webm', '.mp3').replace('.m4a', '.mp3')
            return {
                "success": True,
                "title": title,
                "download_url": f"/downloads/{os.path.basename(filename)}"
            }
    except Exception as e:
        return {"success": False, "error": str(e)}