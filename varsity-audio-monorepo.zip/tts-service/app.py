from flask import Flask, request, send_file
from gtts import gTTS
import os

app = Flask(__name__)

@app.route('/tts', methods=['POST'])
def text_to_speech():
    data = request.json
    text = data.get('text', '')
    if not text:
        return {'error': 'No text provided'}, 400

    tts = gTTS(text)
    filepath = 'output.mp3'
    tts.save(filepath)

    return send_file(filepath, as_attachment=True)

if __name__ == '__main__':
    app.run(port=5001)